<template>
	<header>
		<h1>
			TODO List
		</h1>
	</header>
</template>

<script>
	export default {

	}
</script>

<style>
	h1 {
		padding-top: 20px;
		text-align: center;
		font-weight: 500;
	}
</style>